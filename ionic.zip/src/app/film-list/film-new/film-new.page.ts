import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-film-new',
  templateUrl: './film-new.page.html',
  styleUrls: ['./film-new.page.scss'],
})
export class FilmNewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
