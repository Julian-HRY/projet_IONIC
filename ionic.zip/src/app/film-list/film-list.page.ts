import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-film-list',
  templateUrl: './film-list.page.html',
  styleUrls: ['./film-list.page.scss'],
})
export class FilmListPage implements OnInit {
  films: any = [
    {
      id: 1,
      title: 'titre 1',
      img: '/assets/noimg.jpg',
      param1: 'param 1',
      param2: 'param 2'
    },
    {
      id: 2,
      title: 'titre 2',
      img: '/assets/noimg.jpg',
      param1: 'param 1',
      param2: 'param 2'
    },
    {
      id: 3,
      title: 'titre 3',
      img: '/assets/noimg.jpg',
      param1: 'param 1',
      param2: 'param 2'
    },
    {
      id: 4,
      title: 'titre 4',
      img: '/assets/noimg.jpg',
      param1: 'param 1',
      param2: 'param 2'
    }
  ];
  constructor(
  ) { }

  ngOnInit() {
  }

}
