import { Films } from './films.model';

describe('Films', () => {
  it('should create an instance', () => {
    expect(new Films()).toBeTruthy();
  });
});
